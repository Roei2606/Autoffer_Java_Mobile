package com.example.projects_sdk.models;

import java.util.List;

public class Project {

    private String id;
    private String clientId;
    private String projectAddress;
    private List<ProjectItem> items;
    private List<String> factoryIds;
    private List<Quote> quotes;
    private String createdAt; // תאריך בפורמט String
    private List<Byte> boqPdf;

    public Project() {
    }

    public Project(String id, String clientId, String projectAddress, List<ProjectItem> items,
                   List<String> factoryIds, List<Quote> quotes, String createdAt, List<Byte> boqPdf) {
        this.id = id;
        this.clientId = clientId;
        this.projectAddress = projectAddress;
        this.items = items;
        this.factoryIds = factoryIds;
        this.quotes = quotes;
        this.createdAt = createdAt;
        this.boqPdf = boqPdf;
    }

    public String getId() {
        return id;
    }

    public String getClientId() {
        return clientId;
    }

    public String getProjectAddress() {
        return projectAddress;
    }

    public List<ProjectItem> getItems() {
        return items;
    }

    public List<String> getFactoryIds() {
        return factoryIds;
    }

    public List<Quote> getQuotes() {
        return quotes;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public List<Byte> getBoqPdf() {
        return boqPdf;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public void setProjectAddress(String projectAddress) {
        this.projectAddress = projectAddress;
    }

    public void setItems(List<ProjectItem> items) {
        this.items = items;
    }

    public void setFactoryIds(List<String> factoryIds) {
        this.factoryIds = factoryIds;
    }

    public void setQuotes(List<Quote> quotes) {
        this.quotes = quotes;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public void setBoqPdf(List<Byte> boqPdf) {
        this.boqPdf = boqPdf;
    }
}
