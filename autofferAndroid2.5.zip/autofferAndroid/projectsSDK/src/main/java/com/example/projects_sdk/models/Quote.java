package com.example.projects_sdk.models;

import java.util.List;

public class Quote {

    private String id;
    private String factoryId;
    private String projectId;
    private List<ProjectItem> pricedItems;
    private double factor;
    private double finalPrice;
    private List<Byte> quotePdf;
    private String status; // RECEIVED, CONFIRMED, DECLINED
    private String createdAt;

    public Quote() {
    }

    public Quote(String id, String factoryId, String projectId, List<ProjectItem> pricedItems,
                 double factor, double finalPrice, List<Byte> quotePdf, String status, String createdAt) {
        this.id = id;
        this.factoryId = factoryId;
        this.projectId = projectId;
        this.pricedItems = pricedItems;
        this.factor = factor;
        this.finalPrice = finalPrice;
        this.quotePdf = quotePdf;
        this.status = status;
        this.createdAt = createdAt;
    }

    public String getId() {
        return id;
    }

    public String getFactoryId() {
        return factoryId;
    }

    public String getProjectId() {
        return projectId;
    }

    public List<ProjectItem> getPricedItems() {
        return pricedItems;
    }

    public double getFactor() {
        return factor;
    }

    public double getFinalPrice() {
        return finalPrice;
    }

    public List<Byte> getQuotePdf() {
        return quotePdf;
    }

    public String getStatus() {
        return status;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setFactoryId(String factoryId) {
        this.factoryId = factoryId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public void setPricedItems(List<ProjectItem> pricedItems) {
        this.pricedItems = pricedItems;
    }

    public void setFactor(double factor) {
        this.factor = factor;
    }

    public void setFinalPrice(double finalPrice) {
        this.finalPrice = finalPrice;
    }

    public void setQuotePdf(List<Byte> quotePdf) {
        this.quotePdf = quotePdf;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
}

