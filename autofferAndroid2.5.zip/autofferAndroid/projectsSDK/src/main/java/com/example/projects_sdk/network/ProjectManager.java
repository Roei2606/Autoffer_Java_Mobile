package com.example.projects_sdk.network;


import android.util.Log;

import com.example.projects_sdk.models.Project;
import com.example.projects_sdk.requests.UpdateProjectItemsRequest;
import com.example.rsocket_sdk.network.RSocketClientManager;
import com.example.rsocket_sdk.network.RSocketUtils;

import java.util.concurrent.CompletableFuture;
import io.rsocket.Payload;
import io.rsocket.RSocket;

public class ProjectManager {

    private final RSocketClientManager rSocketClientManager;

    public ProjectManager() {
        this.rSocketClientManager = RSocketClientManager.getInstance();
    }

    private RSocket getActiveRSocket() {
        RSocket rSocket = rSocketClientManager.getRSocket();
        if (rSocket == null || rSocket.isDisposed()) {
            throw new IllegalStateException("RSocket connection is not established");
        }
        return rSocket;
    }

    // ✅ עדכון רק של רשימת items בפרויקט
    public CompletableFuture<Void> updateProjectItems(UpdateProjectItemsRequest request) {
        try {
            Payload payload = RSocketUtils.buildPayload("projects.updateItems", request);
            return getActiveRSocket()
                    .requestResponse(payload)
                    .then()
                    .toFuture();
        } catch (Exception e) {
            Log.e("ProjectManager", "Failed to update project items", e);
            CompletableFuture<Void> future = new CompletableFuture<>();
            future.completeExceptionally(e);
            return future;
        }
    }

    // ✅ שליפת פרויקט לפי ID
    public CompletableFuture<Project> getProjectById(String projectId) {
        try {
            Payload payload = RSocketUtils.buildPayload("projects.getById", projectId);
            return getActiveRSocket()
                    .requestResponse(payload)
                    .map(p -> RSocketUtils.parsePayload(p, Project.class))
                    .toFuture();
        } catch (Exception e) {
            Log.e("ProjectManager", "Failed to load project", e);
            CompletableFuture<Project> future = new CompletableFuture<>();
            future.completeExceptionally(e);
            return future;
        }
    }
}

