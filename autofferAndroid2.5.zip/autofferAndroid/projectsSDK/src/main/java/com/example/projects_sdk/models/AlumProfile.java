package com.example.projects_sdk.models;



public class AlumProfile {

    private String profileNumber;
    private String type; // "Sliding Window", "Opening Door", etc.
    private double pricePerMeter;

    public AlumProfile() {
    }

    public AlumProfile(String profileNumber, String type, double pricePerMeter) {
        this.profileNumber = profileNumber;
        this.type = type;
        this.pricePerMeter = pricePerMeter;
    }

    public String getProfileNumber() {
        return profileNumber;
    }

    public void setProfileNumber(String profileNumber) {
        this.profileNumber = profileNumber;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getPricePerMeter() {
        return pricePerMeter;
    }

    public void setPricePerMeter(double pricePerMeter) {
        this.pricePerMeter = pricePerMeter;
    }
}

