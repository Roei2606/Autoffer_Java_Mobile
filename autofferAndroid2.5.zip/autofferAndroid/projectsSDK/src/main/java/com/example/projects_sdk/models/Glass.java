package com.example.projects_sdk.models;



public class Glass {

    private String type; // "triplex 3+3", "triplex 4+4", etc.
    private double pricePerMeter;

    public Glass() {
    }

    public Glass(String type, double pricePerMeter) {
        this.type = type;
        this.pricePerMeter = pricePerMeter;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getPricePerMeter() {
        return pricePerMeter;
    }

    public void setPricePerMeter(double pricePerMeter) {
        this.pricePerMeter = pricePerMeter;
    }
}
