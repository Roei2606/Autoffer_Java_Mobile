package com.example.chat_sdk.network;

import android.util.Log;

import com.example.chat_sdk.models.User;
import com.example.chat_sdk.requests.LoginRequest;
import com.example.chat_sdk.requests.RegisterUserRequest;
import com.example.chat_sdk.requests.ResetPasswordRequest;
import com.example.chat_sdk.requests.UserIdRequest;
import com.example.rsocket_sdk.network.RSocketClientManager;
import com.example.rsocket_sdk.network.RSocketUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import io.rsocket.Payload;
import io.rsocket.RSocket;

public class UserManager {
    private final RSocketClientManager rSocketClientManager;
    private static final String TAG = "UserManager";

    public UserManager() {
        this.rSocketClientManager = RSocketClientManager.getInstance();
    }

    public CompletableFuture<User> loginUser(String email, String password) {
        CompletableFuture<User> future = new CompletableFuture<>();

        try {
            RSocket rSocket = getActiveRSocket();
            LoginRequest request = new LoginRequest(email, password);
            Payload payload = RSocketUtils.buildPayload("users.login", request);

            rSocket.requestResponse(payload)
                    .map(response -> RSocketUtils.parsePayload(response, User.class))
                    .subscribe(
                            future::complete,
                            error -> {
                                Log.e(TAG, "Login Error: " + error.getMessage(), error);
                                future.completeExceptionally(error);
                            }
                    );

        } catch (Exception e) {
            Log.e(TAG, "RSocket Request Failed: " + e.getMessage(), e);
            future.completeExceptionally(e);
        }

        return future;
    }

    public CompletableFuture<User> registerUser(RegisterUserRequest request) {
        CompletableFuture<User> future = new CompletableFuture<>();

        try {
            RSocket rSocket = getActiveRSocket();
            Payload payload = RSocketUtils.buildPayload("users.register", request);

            rSocket.requestResponse(payload)
                    .map(response -> RSocketUtils.parsePayload(response, User.class))
                    .subscribe(
                            future::complete,
                            error -> {
                                Log.e(TAG, "Register Error: " + error.getMessage(), error);
                                future.completeExceptionally(error);
                            }
                    );

        } catch (Exception e) {
            Log.e(TAG, "Register RSocket Request Failed: " + e.getMessage(), e);
            future.completeExceptionally(e);
        }

        return future;
    }

    public CompletableFuture<List<User>> getAllUsers() {
        CompletableFuture<List<User>> future = new CompletableFuture<>();

        try {
            RSocket rSocket = getActiveRSocket();
            Payload payload = RSocketUtils.buildPayload("users.getAll", "");

            rSocket.requestStream(payload)
                    .collectList()
                    .map(responses -> {
                        List<User> users = new ArrayList<>();
                        for (Payload response : responses) {
                            users.add(RSocketUtils.parsePayload(response, User.class));
                        }
                        return users;
                    })
                    .subscribe(
                            future::complete,
                            error -> {
                                Log.e(TAG, "GetAllUsers Error: " + error.getMessage(), error);
                                future.completeExceptionally(error);
                            }
                    );

        } catch (Exception e) {
            Log.e(TAG, "RSocket Request Failed: " + e.getMessage(), e);
            future.completeExceptionally(e);
        }

        return future;
    }

    public CompletableFuture<User> getUserById(String userId) {
        try {
            UserIdRequest request = new UserIdRequest(userId);
            Payload payload = RSocketUtils.buildPayload("users.getById", request);
            return getActiveRSocket()
                    .requestResponse(payload)
                    .map(p -> RSocketUtils.parsePayload(p, User.class))
                    .toFuture();
        } catch (Exception e) {
            CompletableFuture<User> future = new CompletableFuture<>();
            future.completeExceptionally(e);
            return future;
        }
    }

    public CompletableFuture<Void> resetPassword(ResetPasswordRequest request) {
        CompletableFuture<Void> future = new CompletableFuture<>();

        try {
            RSocket rSocket = getActiveRSocket();
            Payload payload = RSocketUtils.buildPayload("users.resetPassword", request);

            rSocket.requestResponse(payload)
                    .subscribe(
                            response -> future.complete(null),
                            error -> {
                                Log.e(TAG, "Reset password error: " + error.getMessage(), error);
                                future.completeExceptionally(error);
                            }
                    );

        } catch (Exception e) {
            Log.e(TAG, "Reset password RSocket Request Failed: " + e.getMessage(), e);
            future.completeExceptionally(e);
        }

        return future;
    }

    private RSocket getActiveRSocket() {
        RSocket rSocket = rSocketClientManager.getRSocket();
        if (rSocket == null || rSocket.isDisposed()) {
            throw new IllegalStateException("RSocket connection is not established");
        }
        return rSocket;
    }
}
