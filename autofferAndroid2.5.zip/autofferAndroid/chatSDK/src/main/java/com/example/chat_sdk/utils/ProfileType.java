package com.example.chat_sdk.utils;

public enum ProfileType {
    PRIVATE_CUSTOMER,
    ARCHITECT
}
