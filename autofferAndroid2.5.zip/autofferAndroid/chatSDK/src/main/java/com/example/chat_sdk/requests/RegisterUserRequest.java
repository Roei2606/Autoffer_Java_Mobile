package com.example.chat_sdk.requests;


import com.example.chat_sdk.utils.ProfileType;

public class RegisterUserRequest {
    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private String phoneNumber;
    private String address;
    private ProfileType profileType;

    public RegisterUserRequest() {
    }

    public RegisterUserRequest(String firstName, String lastName, String email, String password,
                               String phoneNumber, String address, ProfileType profileType) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.profileType = profileType;
    }

    public String getFirstName() {
        return firstName;
    }

    public RegisterUserRequest setFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    public String getLastName() {
        return lastName;
    }

    public RegisterUserRequest setLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public String getEmail() {
        return email;
    }

    public RegisterUserRequest setEmail(String email) {
        this.email = email;
        return this;
    }

    public String getPassword() {
        return password;
    }

    public RegisterUserRequest setPassword(String password) {
        this.password = password;
        return this;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public RegisterUserRequest setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
        return this;
    }

    public String getAddress() {
        return address;
    }

    public RegisterUserRequest setAddress(String address) {
        this.address = address;
        return this;
    }

    public ProfileType getProfileType() {
        return profileType;
    }

    public RegisterUserRequest setProfileType(ProfileType profileType) {
        this.profileType = profileType;
        return this;
    }
}
