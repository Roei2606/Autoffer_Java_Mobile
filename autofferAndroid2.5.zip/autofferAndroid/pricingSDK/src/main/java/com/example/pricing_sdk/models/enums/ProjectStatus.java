package com.example.pricing_sdk.models.enums;


public enum ProjectStatus {
    PENDING,
    RECEIVED,
    CONFIRMED,
    DECLINED
}

