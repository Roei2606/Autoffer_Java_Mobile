package com.example.pricing_sdk.utils;

import com.example.pricing_sdk.models.Item;

public class PricingUtils {

    /**
     * מחשב את המחיר של פריט בודד לפי פקטור
     *
     * @param item הפריט לחישוב
     * @param factor פקטור המפעל
     * @return המחיר המשוקלל
     */
    public static double calculateItemPrice(Item item, double factor) {
        double profileCost = item.getProfileModel().getPricePerMeter();
        double glassCost = item.getGlassModel().getPricePerMeter();

        // נניח שחישוב שטח הוא רוחב * גובה (במטרים)
        double area = item.getWidth() * item.getHeight();

        // חישוב בסיסי של מחיר למ"ר ואז כפל בכמות
        double basePrice = (profileCost + glassCost) * area;
        double totalPrice = basePrice * item.getQuantity();

        // הוספת פקטור המפעל
        return totalPrice * factor;
    }
}
