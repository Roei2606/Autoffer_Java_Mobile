package com.example.pricing_sdk.models;

import com.example.pricing_sdk.models.enums.ProjectStatus;

public class FactoryStatusEntry {
    private String factoryId;
    private ProjectStatus status;
    private String quotationId; // יכול להיות null אם עדיין לא התקבלה הצעה

    public FactoryStatusEntry() {}

    public FactoryStatusEntry(String factoryId, ProjectStatus status, String quotationId) {
        this.factoryId = factoryId;
        this.status = status;
        this.quotationId = quotationId;
    }

    public String getFactoryId() {
        return factoryId;
    }

    public ProjectStatus getStatus() {
        return status;
    }

    public String getQuotationId() {
        return quotationId;
    }
}
