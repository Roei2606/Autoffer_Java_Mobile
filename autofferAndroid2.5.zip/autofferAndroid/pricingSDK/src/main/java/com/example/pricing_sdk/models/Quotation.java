package com.example.pricing_sdk.models;

import java.util.List;

public class Quotation {
    private String id;
    private String projectId;
    private String factoryId;
    private List<Item> pricedItems;
    private double totalPrice;
    private double factorUsed;
    private String createdAt;

    public Quotation() {}

    public Quotation(String id, String projectId, String factoryId, List<Item> pricedItems,
                     double totalPrice, double factorUsed, String createdAt) {
        this.id = id;
        this.projectId = projectId;
        this.factoryId = factoryId;
        this.pricedItems = pricedItems;
        this.totalPrice = totalPrice;
        this.factorUsed = factorUsed;
        this.createdAt = createdAt;
    }

    public String getId() {
        return id;
    }

    public String getProjectId() {
        return projectId;
    }

    public String getFactoryId() {
        return factoryId;
    }

    public List<Item> getPricedItems() {
        return pricedItems;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public double getFactorUsed() {
        return factorUsed;
    }

    public String getCreatedAt() {
        return createdAt;
    }
}
