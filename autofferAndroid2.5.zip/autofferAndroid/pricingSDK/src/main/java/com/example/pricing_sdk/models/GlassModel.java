package com.example.pricing_sdk.models;

public class GlassModel {
    private String type; // סוג זכוכית, למשל triplex 3+3
    private double pricePerMeter;

    public GlassModel() {}

    public GlassModel(String type, double pricePerMeter) {
        this.type = type;
        this.pricePerMeter = pricePerMeter;
    }

    public String getType() {
        return type;
    }

    public double getPricePerMeter() {
        return pricePerMeter;
    }
}
