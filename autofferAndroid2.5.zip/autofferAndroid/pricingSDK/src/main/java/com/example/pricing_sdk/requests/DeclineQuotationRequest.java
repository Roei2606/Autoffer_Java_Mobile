package com.example.pricing_sdk.requests;



public class DeclineQuotationRequest {
    private String projectId;
    private String factoryId;

    public DeclineQuotationRequest() {}

    public DeclineQuotationRequest(String projectId, String factoryId) {
        this.projectId = projectId;
        this.factoryId = factoryId;
    }

    public String getProjectId() {
        return projectId;
    }

    public String getFactoryId() {
        return factoryId;
    }
}

