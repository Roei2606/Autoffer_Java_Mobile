package com.example.pricing_sdk.models;



import com.example.pricing_sdk.models.enums.SourceType;

public class Item {
    private String id;
    private ProfileModel profileModel;
    private GlassModel glassModel;
    private double width;
    private double height;
    private int quantity;
    private SourceType sourceType;

    public Item() {}

    public Item(String id, ProfileModel profileModel, GlassModel glassModel,
                double width, double height, int quantity, SourceType sourceType) {
        this.id = id;
        this.profileModel = profileModel;
        this.glassModel = glassModel;
        this.width = width;
        this.height = height;
        this.quantity = quantity;
        this.sourceType = sourceType;
    }

    public String getId() {
        return id;
    }

    public ProfileModel getProfileModel() {
        return profileModel;
    }

    public GlassModel getGlassModel() {
        return glassModel;
    }

    public double getWidth() {
        return width;
    }

    public double getHeight() {
        return height;
    }

    public int getQuantity() {
        return quantity;
    }

    public SourceType getSourceType() {
        return sourceType;
    }
}

