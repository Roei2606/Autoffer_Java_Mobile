package com.example.pricing_sdk.models.enums;

public enum SourceType {
    CAMERA,
    DOCUMENT,
    MANUAL
}
