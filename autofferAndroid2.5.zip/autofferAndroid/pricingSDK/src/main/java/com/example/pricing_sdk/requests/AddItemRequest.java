package com.example.pricing_sdk.requests;


import com.example.pricing_sdk.models.Item;

public class AddItemRequest {
    private String projectId;
    private Item item;

    public AddItemRequest() {}

    public AddItemRequest(String projectId, Item item) {
        this.projectId = projectId;
        this.item = item;
    }

    public String getProjectId() {
        return projectId;
    }

    public Item getItem() {
        return item;
    }
}

