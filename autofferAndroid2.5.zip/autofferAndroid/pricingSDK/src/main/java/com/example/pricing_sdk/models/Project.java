package com.example.pricing_sdk.models;


import java.util.List;

public class Project {
    private String id;
    private String clientId;
    private String projectAddress;
    private List<FactoryStatusEntry> factories;
    private List<Item> items;
    private List<Quotation> quotations;
    private String createdAt;
    private String updatedAt;

    public Project() {}

    public Project(String id, String clientId, String projectAddress, List<FactoryStatusEntry> factories,
                   List<Item> items, List<Quotation> quotations, String createdAt, String updatedAt) {
        this.id = id;
        this.clientId = clientId;
        this.projectAddress = projectAddress;
        this.factories = factories;
        this.items = items;
        this.quotations = quotations;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public String getId() {
        return id;
    }

    public String getClientId() {
        return clientId;
    }

    public String getProjectAddress() {
        return projectAddress;
    }

    public List<FactoryStatusEntry> getFactories() {
        return factories;
    }

    public List<Item> getItems() {
        return items;
    }

    public List<Quotation> getQuotations() {
        return quotations;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }
}

