package com.example.pricing_sdk.network;



public class PricingRoutes {
    public static final String CREATE_PROJECT = "pricing.createProject";
    public static final String ADD_ITEM = "pricing.addItem";
    public static final String SEND_QUOTATION_REQUEST = "pricing.sendQuotationRequest";
    public static final String GET_QUOTATIONS = "pricing.getQuotations";
    public static final String SUBMIT_PRICED_QUOTATION = "pricing.submitPricedQuotation";
    public static final String CONFIRM_QUOTATION = "pricing.confirmQuotation";
    public static final String DECLINE_QUOTATION = "pricing.declineQuotation";

    // TODOs עתידיים
    public static final String SCAN_OPENING_FROM_CAMERA = "pricing.scanOpeningFromCamera";
    public static final String ANALYZE_ARCHITECTURAL_DOCUMENT = "pricing.analyzeArchitecturalDocument";
}

