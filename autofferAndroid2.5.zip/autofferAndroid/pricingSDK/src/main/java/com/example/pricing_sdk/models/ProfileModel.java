package com.example.pricing_sdk.models;


public class ProfileModel {
    private String profileNumber;
    private String type; // סוג פרופיל: חלון הזזה, פתיחה, דלת וכו'
    private double pricePerMeter;

    public ProfileModel() {}

    public ProfileModel(String profileNumber, String type, double pricePerMeter) {
        this.profileNumber = profileNumber;
        this.type = type;
        this.pricePerMeter = pricePerMeter;
    }

    public String getProfileNumber() {
        return profileNumber;
    }

    public String getType() {
        return type;
    }

    public double getPricePerMeter() {
        return pricePerMeter;
    }
}

