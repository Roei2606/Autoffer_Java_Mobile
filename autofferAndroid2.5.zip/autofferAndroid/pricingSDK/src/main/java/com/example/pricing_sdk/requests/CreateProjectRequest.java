package com.example.pricing_sdk.requests;
import java.util.List;

public class CreateProjectRequest {
    private String clientId;
    private String projectAddress;
    private List<String> factoryIds;

    public CreateProjectRequest() {}

    public CreateProjectRequest(String clientId, String projectAddress, List<String> factoryIds) {
        this.clientId = clientId;
        this.projectAddress = projectAddress;
        this.factoryIds = factoryIds;
    }

    public String getClientId() {
        return clientId;
    }

    public String getProjectAddress() {
        return projectAddress;
    }

    public List<String> getFactoryIds() {
        return factoryIds;
    }
}

