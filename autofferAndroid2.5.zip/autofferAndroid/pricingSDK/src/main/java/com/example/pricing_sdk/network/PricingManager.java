package com.example.pricing_sdk.network;
import com.example.pricing_sdk.models.Project;
import com.example.pricing_sdk.models.Item;
import com.example.pricing_sdk.models.Quotation;
import com.example.pricing_sdk.requests.*;
import com.example.rsocket_sdk.network.RSocketClientManager;
import com.example.rsocket_sdk.network.RSocketUtils;


import io.rsocket.Payload;
import io.rsocket.RSocket;

import java.util.List;
import java.util.concurrent.CompletableFuture;

public class PricingManager {
    private final RSocketClientManager rSocketClientManager;

    public PricingManager() {
        this.rSocketClientManager = RSocketClientManager.getInstance();
    }

    private RSocket getActiveRSocket() {
        RSocket rSocket = rSocketClientManager.getRSocket();
        if (rSocket == null || rSocket.isDisposed()) {
            throw new IllegalStateException("RSocket connection is not established");
        }
        return rSocket;
    }

    public CompletableFuture<Project> createProject(CreateProjectRequest request) {
        try {
            Payload payload = RSocketUtils.buildPayload(PricingRoutes.CREATE_PROJECT, request);

            return getActiveRSocket()
                    .requestResponse(payload)
                    .map(p -> RSocketUtils.parsePayload(p, Project.class))
                    .toFuture();
        } catch (Exception e) {
            CompletableFuture<Project> future = new CompletableFuture<>();
            future.completeExceptionally(e);
            return future;
        }
    }

    public CompletableFuture<Item> addItem(AddItemRequest request) {
        try {
            Payload payload = RSocketUtils.buildPayload(PricingRoutes.ADD_ITEM, request);

            return getActiveRSocket()
                    .requestResponse(payload)
                    .map(p -> RSocketUtils.parsePayload(p, Item.class))
                    .toFuture();
        } catch (Exception e) {
            CompletableFuture<Item> future = new CompletableFuture<>();
            future.completeExceptionally(e);
            return future;
        }
    }

    public CompletableFuture<Void> sendQuotationRequest(SendQuotationRequest request) {
        try {
            Payload payload = RSocketUtils.buildPayload(PricingRoutes.SEND_QUOTATION_REQUEST, request);

            return getActiveRSocket()
                    .requestResponse(payload)
                    .then()
                    .toFuture();
        } catch (Exception e) {
            CompletableFuture<Void> future = new CompletableFuture<>();
            future.completeExceptionally(e);
            return future;
        }
    }

    public CompletableFuture<List<Quotation>> getQuotations(GetQuotationsRequest request) {
        try {
            Payload payload = RSocketUtils.buildPayload(PricingRoutes.GET_QUOTATIONS, request);

            return getActiveRSocket()
                    .requestStream(payload)
                    .map(p -> RSocketUtils.parsePayload(p, Quotation.class))
                    .collectList()
                    .toFuture();
        } catch (Exception e) {
            CompletableFuture<List<Quotation>> future = new CompletableFuture<>();
            future.completeExceptionally(e);
            return future;
        }
    }

    public CompletableFuture<Void> submitPricedQuotation(SubmitPricedQuotationRequest request) {
        try {
            Payload payload = RSocketUtils.buildPayload(PricingRoutes.SUBMIT_PRICED_QUOTATION, request);

            return getActiveRSocket()
                    .requestResponse(payload)
                    .then()
                    .toFuture();
        } catch (Exception e) {
            CompletableFuture<Void> future = new CompletableFuture<>();
            future.completeExceptionally(e);
            return future;
        }
    }

    public CompletableFuture<Void> confirmQuotation(ConfirmQuotationRequest request) {
        try {
            Payload payload = RSocketUtils.buildPayload(PricingRoutes.CONFIRM_QUOTATION, request);

            return getActiveRSocket()
                    .requestResponse(payload)
                    .then()
                    .toFuture();
        } catch (Exception e) {
            CompletableFuture<Void> future = new CompletableFuture<>();
            future.completeExceptionally(e);
            return future;
        }
    }

    public CompletableFuture<Void> declineQuotation(DeclineQuotationRequest request) {
        try {
            Payload payload = RSocketUtils.buildPayload(PricingRoutes.DECLINE_QUOTATION, request);

            return getActiveRSocket()
                    .requestResponse(payload)
                    .then()
                    .toFuture();
        } catch (Exception e) {
            CompletableFuture<Void> future = new CompletableFuture<>();
            future.completeExceptionally(e);
            return future;
        }
    }
}

