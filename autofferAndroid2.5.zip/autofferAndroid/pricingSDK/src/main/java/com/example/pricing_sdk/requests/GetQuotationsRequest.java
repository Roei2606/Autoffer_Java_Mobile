package com.example.pricing_sdk.requests;


public class GetQuotationsRequest {
    private String projectId;

    public GetQuotationsRequest() {}

    public GetQuotationsRequest(String projectId) {
        this.projectId = projectId;
    }

    public String getProjectId() {
        return projectId;
    }
}

