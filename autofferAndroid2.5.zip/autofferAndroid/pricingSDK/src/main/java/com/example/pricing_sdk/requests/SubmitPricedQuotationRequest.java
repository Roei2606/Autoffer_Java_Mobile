package com.example.pricing_sdk.requests;


import com.example.pricing_sdk.models.Quotation;

public class SubmitPricedQuotationRequest {
    private String projectId;
    private String factoryId;
    private Quotation quotation;

    public SubmitPricedQuotationRequest() {}

    public SubmitPricedQuotationRequest(String projectId, String factoryId, Quotation quotation) {
        this.projectId = projectId;
        this.factoryId = factoryId;
        this.quotation = quotation;
    }

    public String getProjectId() {
        return projectId;
    }

    public String getFactoryId() {
        return factoryId;
    }

    public Quotation getQuotation() {
        return quotation;
    }
}

