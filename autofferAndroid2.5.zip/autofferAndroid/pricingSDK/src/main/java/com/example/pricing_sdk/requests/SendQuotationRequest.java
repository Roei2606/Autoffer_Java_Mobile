package com.example.pricing_sdk.requests;



public class SendQuotationRequest {
    private String projectId;

    public SendQuotationRequest() {}

    public SendQuotationRequest(String projectId) {
        this.projectId = projectId;
    }

    public String getProjectId() {
        return projectId;
    }
}

