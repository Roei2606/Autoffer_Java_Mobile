package com.example.autofferandroid.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.airbnb.lottie.LottieAnimationView;
import com.example.autofferandroid.adapters.EditItemAdapter;
import com.example.autofferandroid.databinding.FragmentEditProjectBinding;
import com.example.projects_sdk.models.ProjectItem;
import com.example.projects_sdk.network.ProjectManager;
import com.example.projects_sdk.requests.UpdateProjectItemsRequest;


import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class EditProjectFragment extends Fragment {

    private FragmentEditProjectBinding binding;
    private EditItemAdapter adapter;
    private List<ProjectItem> originalItems = new ArrayList<>();
    private List<ProjectItem> currentItems = new ArrayList<>();
    private String projectId;
    private ProjectManager projectManager;

    public EditProjectFragment(String projectId) {
        this.projectId = projectId;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentEditProjectBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        projectManager = new ProjectManager();

        setupRecyclerView();
        loadProjectItems();

        binding.saveButton.setOnClickListener(v -> saveChanges());
    }

    private void setupRecyclerView() {
        adapter = new EditItemAdapter(currentItems, item -> {
            currentItems.remove(item);
            adapter.notifyDataSetChanged();
        });
        binding.itemsRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.itemsRecyclerView.setAdapter(adapter);
    }

    private void loadProjectItems() {
        showLoading(true);
        projectManager.getProjectById(projectId).thenAccept(project -> {
            if (project != null) {
                originalItems = new ArrayList<>(project.getItems());
                currentItems.clear();
                for (ProjectItem item : originalItems) {
                    currentItems.add(new ProjectItem(item));
                }
                adapter.notifyDataSetChanged();
            }
            showLoading(false);
        }).exceptionally(e -> {
            showLoading(false);
            Toast.makeText(getContext(), "Failed to load project items", Toast.LENGTH_SHORT).show();
            return null;
        });
    }

    private void saveChanges() {
        if (!hasChanges()) {
            Toast.makeText(getContext(), "No changes to save", Toast.LENGTH_SHORT).show();
            return;
        }

        showLoading(true);
        UpdateProjectItemsRequest request = new UpdateProjectItemsRequest(projectId, currentItems);
        projectManager.updateProjectItems(request).thenRun(() -> {
            showLoading(false);
            Toast.makeText(getContext(), "Changes saved successfully", Toast.LENGTH_SHORT).show();
            getParentFragmentManager().popBackStack();
        }).exceptionally(e -> {
            showLoading(false);
            Toast.makeText(getContext(), "Failed to save changes", Toast.LENGTH_SHORT).show();
            return null;
        });
    }

    private boolean hasChanges() {
        if (originalItems.size() != currentItems.size()) return true;
        for (int i = 0; i < originalItems.size(); i++) {
            ProjectItem original = originalItems.get(i);
            ProjectItem current = currentItems.get(i);
            if (!original.equals(current)) return true;
        }
        return false;
    }

    private void showLoading(boolean isLoading) {
        binding.loadingIndicator.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        binding.saveButton.setEnabled(!isLoading);
    }
}
