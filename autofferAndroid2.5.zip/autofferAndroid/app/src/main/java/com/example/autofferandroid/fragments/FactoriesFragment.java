package com.example.autofferandroid.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import com.example.autofferandroid.databinding.FragmentFactoriesBinding;

public class FactoriesFragment extends Fragment {

    private FragmentFactoriesBinding binding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentFactoriesBinding.inflate(inflater, container, false);

        binding.textFactories.setText("Factories List");

        return binding.getRoot();
    }
}
