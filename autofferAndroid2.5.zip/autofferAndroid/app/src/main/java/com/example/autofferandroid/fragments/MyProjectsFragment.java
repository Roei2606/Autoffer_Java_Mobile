package com.example.autofferandroid.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import com.example.autofferandroid.databinding.FragmentMyProjectsBinding;

public class MyProjectsFragment extends Fragment {

    private FragmentMyProjectsBinding binding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentMyProjectsBinding.inflate(inflater, container, false);

        binding.textMyProjects.setText("My Projects");

        return binding.getRoot();
    }
}
