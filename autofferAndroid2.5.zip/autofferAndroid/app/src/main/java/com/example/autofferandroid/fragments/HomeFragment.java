package com.example.autofferandroid.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.ads_sdk.models.Ad;
import com.example.ads_sdk.models.ProfileType;
import com.example.ads_sdk.network.AdsManager;
import com.example.autofferandroid.adapters.AdsAdapter;
import com.example.autofferandroid.databinding.FragmentHomeBinding;
import com.example.autofferandroid.transformers.DoorOpenPageTransformer;
import com.example.chat_sdk.models.User;
import com.example.chat_sdk.utils.SessionManager;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private AdsAdapter adsAdapter;
    private AdsManager adsManager;
    private final List<Ad> adList = new ArrayList<>();

    private Runnable autoScrollRunnable;
    private static final long AUTO_SCROLL_DELAY = 4000; // 4 seconds

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        adsManager = new AdsManager();
        adsAdapter = new AdsAdapter(adList, requireContext());
        binding.viewPagerAds.setAdapter(adsAdapter);
        binding.viewPagerAds.setPageTransformer(new DoorOpenPageTransformer());

        setupUserDetails();
        loadAds();
    }

    private void setupUserDetails() {
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser != null) {
            binding.textViewUserName.setText("Hello, " + currentUser.getFirstName() + "!");
            binding.textViewUserType.setText(currentUser.getProfileType());
        } else {
            binding.textViewUserName.setText("Hello, Guest!");
            binding.textViewUserType.setText("Unknown Type");
        }
    }

    private void loadAds() {
        showLoading(true);

        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser == null) {
            showLoading(false);
            return;
        }

        try {
            // המרה ל-ProfileType
            ProfileType profileType = ProfileType.valueOf(currentUser.getProfileType());

            CompletableFuture<List<Ad>> future = adsManager.getAdsForAudience(profileType);
            future.thenAccept(ads -> {
                requireActivity().runOnUiThread(() -> {
                    adList.clear();
                    adList.addAll(ads);
                    adsAdapter.notifyDataSetChanged();
                    showLoading(false);
                    startAutoScroll(); // 🔥 מתחילים גלילה אוטומטית אחרי שהפרסומות נטענו
                });
            }).exceptionally(e -> {
                e.printStackTrace();
                requireActivity().runOnUiThread(() -> showLoading(false));
                return null;
            });
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
            showLoading(false);
        }
    }

    private void showLoading(boolean isLoading) {
        if (isLoading) {
            binding.loadingIndicator.setVisibility(View.VISIBLE);
            binding.viewPagerAds.setVisibility(View.GONE);
        } else {
            binding.loadingIndicator.setVisibility(View.GONE);
            binding.viewPagerAds.setVisibility(View.VISIBLE);
        }
    }

    private void startAutoScroll() {
        stopAutoScroll(); // לוודא שלא נוצר כמה פעמים

        autoScrollRunnable = new Runnable() {
            @Override
            public void run() {
                int currentItem = binding.viewPagerAds.getCurrentItem();
                int itemCount = adsAdapter.getItemCount();
                if (itemCount > 0) {
                    int nextItem = (currentItem + 1) % itemCount;
                    binding.viewPagerAds.setCurrentItem(nextItem, true);
                }
                binding.viewPagerAds.postDelayed(this, AUTO_SCROLL_DELAY);
            }
        };
        binding.viewPagerAds.postDelayed(autoScrollRunnable, AUTO_SCROLL_DELAY);
    }

    private void stopAutoScroll() {
        if (autoScrollRunnable != null) {
            binding.viewPagerAds.removeCallbacks(autoScrollRunnable);
        }
    }

    @Override
    public void onDestroyView() {
        stopAutoScroll();
        super.onDestroyView();
        binding = null;
    }
}
