package com.example.autofferandroid.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.autofferandroid.R;
import com.example.projects_sdk.models.ProjectItem;


import java.util.List;

public class EditItemAdapter extends RecyclerView.Adapter<EditItemAdapter.ViewHolder> {

    public interface OnItemDeleteListener {
        void onItemDelete(ProjectItem item);
    }

    private List<ProjectItem> items;
    private OnItemDeleteListener deleteListener;

    public EditItemAdapter(List<ProjectItem> items, OnItemDeleteListener deleteListener) {
        this.items = items;
        this.deleteListener = deleteListener;
    }

    @NonNull
    @Override
    public EditItemAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_edit_project_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull EditItemAdapter.ViewHolder holder, int position) {
        ProjectItem item = items.get(position);
        holder.quantityEditText.setText(String.valueOf(item.getQuantity()));
        holder.locationEditText.setText(item.getLocation());
        holder.dimensionsTextView.setText(item.getDimensions());

        holder.quantityEditText.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) {
                String text = holder.quantityEditText.getText().toString();
                int quantity = text.isEmpty() ? 0 : Integer.parseInt(text);
                item.setQuantity(quantity);
            }
        });

        holder.locationEditText.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) {
                item.setLocation(holder.locationEditText.getText().toString());
            }
        });

        holder.deleteButton.setOnClickListener(v -> deleteListener.onItemDelete(item));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        EditText quantityEditText;
        EditText locationEditText;
        TextView dimensionsTextView;
        ImageButton deleteButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            quantityEditText = itemView.findViewById(R.id.edit_quantity);
            locationEditText = itemView.findViewById(R.id.edit_location);
            dimensionsTextView = itemView.findViewById(R.id.text_dimensions);
            deleteButton = itemView.findViewById(R.id.button_delete);
        }
    }
}
