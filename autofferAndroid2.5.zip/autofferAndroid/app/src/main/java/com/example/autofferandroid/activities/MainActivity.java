package com.example.autofferandroid.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.autofferandroid.R;
import com.example.autofferandroid.databinding.ActivityMainBinding;
import com.example.autofferandroid.fragments.ChatsFragment;
import com.example.autofferandroid.fragments.FactoriesFragment;
import com.example.autofferandroid.fragments.HomeFragment;
import com.example.autofferandroid.fragments.MyProjectsFragment;
import com.example.autofferandroid.fragments.NewProjectFragment;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        loadFragment(new HomeFragment()); // ברירת מחדל — מסך הבית

        binding.bottomNavigation.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;

            if (item.getItemId() == R.id.nav_home) {
                selectedFragment = new HomeFragment();
            } else if (item.getItemId() == R.id.nav_chats) {
                selectedFragment = new ChatsFragment();
            } else if (item.getItemId() == R.id.nav_new_project) {
                selectedFragment = new NewProjectFragment();
            } else if (item.getItemId() == R.id.nav_my_projects) {
                selectedFragment = new MyProjectsFragment();
            } else if (item.getItemId() == R.id.nav_factories) {
                selectedFragment = new FactoriesFragment();
            }

            return loadFragment(selectedFragment);
        });
    }

    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
            return true;
        }
        return false;
    }
}
