package com.example.ads_sdk.network;

public class AdsRoutes {
    public static final String GET_ADS_FOR_AUDIENCE = "ads.getAdsForAudience";
}
