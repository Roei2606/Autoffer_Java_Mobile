package com.example.ads_sdk.models;

public enum ProfileType {
    PRIVATE_CUSTOMER,
    ARCHITECT,
    FACTORY
}
